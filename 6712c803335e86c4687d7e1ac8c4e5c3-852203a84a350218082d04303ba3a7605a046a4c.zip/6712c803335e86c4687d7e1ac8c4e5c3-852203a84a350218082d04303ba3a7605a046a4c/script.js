document.addEventListener('DOMContentLoaded', () => {
  // Application State
  let currentUser = null;
  let authMode = 'login';
  let notifications = []; // Leave empty for empty-state test

  // DOM Elements - Auth & Navigation
  const openLoginBtn = document.getElementById('open-login-btn');
  const heroCtaBtn = document.getElementById('hero-cta-btn');
  const closeModalBtn = document.getElementById('close-modal-btn');
  const loginModal = document.getElementById('login-modal');
  const loginForm = document.getElementById('login-form');
  const landingView = document.getElementById('landing-view');
  const appView = document.getElementById('app-view');
  const logoutBtn = document.getElementById('logout-btn');

  // DOM Elements - Auth Tabs & Inputs
  const tabLogin = document.getElementById('tab-login');
  const tabSignup = document.getElementById('tab-signup');
  const modalTitle = document.getElementById('modal-title');
  const modalSubtitle = document.getElementById('modal-subtitle');
  const authSubmitBtn = document.getElementById('auth-submit-btn');
  const toggleAuthLink = document.getElementById('toggle-auth-link');
  const authTogglePrompt = document.getElementById('auth-toggle-prompt');
  const phoneInput = document.getElementById('phone');

  // DOM Elements - User Profile Display
  const displayUsername = document.getElementById('display-username');
  const displayEmail = document.getElementById('display-email');
  const displayPhone = document.getElementById('display-phone');
  const userAvatarInitial = document.getElementById('user-avatar-initial');

  // DOM Elements - Status Feature
  const editStatusBtn = document.getElementById('edit-status-btn');
  const statusModal = document.getElementById('status-modal');
  const closeStatusModal = document.getElementById('close-status-modal');
  const statusForm = document.getElementById('status-form');
  const statusInput = document.getElementById('status-input');
  const displayStatus = document.getElementById('display-status');

  // DOM Elements - Contacts & Notifications
  const contactsBtn = document.getElementById('contacts-btn');
  const contactsModal = document.getElementById('contacts-modal');
  const closeContactsModal = document.getElementById('close-contacts-modal');

  const notificationsBtn = document.getElementById('notifications-btn');
  const notifModal = document.getElementById('notif-modal');
  const closeNotifModal = document.getElementById('close-notif-modal');
  const notifContainer = document.getElementById('notif-container');
  const notifBadge = document.getElementById('notif-badge');

  // DOM Elements - Chat Feature
  const chatForm = document.getElementById('chat-form');
  const messageInput = document.getElementById('message-input');
  const messagesList = document.getElementById('messages-list');

  // --- AUTH MODAL TOGGLES ---
  function showAuthModal() {
    if (loginModal) loginModal.classList.remove('hidden');
  }

  function hideAuthModal() {
    if (loginModal) loginModal.classList.add('hidden');
  }

  function setAuthMode(mode) {
    authMode = mode;
    if (mode === 'signup') {
      tabSignup.classList.add('active');
      tabLogin.classList.remove('active');
      modalTitle.textContent = 'Create an Account';
      modalSubtitle.textContent = 'Join Vibezone today and connect with your tribe!';
      authSubmitBtn.textContent = 'Sign Up';
      authTogglePrompt.textContent = 'Already have an account?';
      toggleAuthLink.textContent = 'Log In';
      phoneInput.required = true;
    } else {
      tabLogin.classList.add('active');
      tabSignup.classList.remove('active');
      modalTitle.textContent = 'Welcome Back';
      modalSubtitle.textContent = 'Enter your details to log back into Vibezone';
      authSubmitBtn.textContent = 'Log In';
      authTogglePrompt.textContent = "Don't have an account?";
      toggleAuthLink.textContent = 'Sign Up';
      phoneInput.required = false;
    }
  }

  if (openLoginBtn) openLoginBtn.addEventListener('click', showAuthModal);
  if (heroCtaBtn) heroCtaBtn.addEventListener('click', showAuthModal);
  if (closeModalBtn) closeModalBtn.addEventListener('click', hideAuthModal);

  if (tabLogin) tabLogin.addEventListener('click', () => setAuthMode('login'));
  if (tabSignup) tabSignup.addEventListener('click', () => setAuthMode('signup'));

  if (toggleAuthLink) {
    toggleAuthLink.addEventListener('click', (e) => {
      e.preventDefault();
      setAuthMode(authMode === 'login' ? 'signup' : 'login');
    });
  }

  // --- LOGIN / SIGNUP SUBMISSION ---
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const username = document.getElementById('username').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();

      currentUser = { username, email, phone, status: 'Feeling great! ✨' };

      displayUsername.textContent = `@${username}`;
      displayEmail.textContent = email;
      displayPhone.textContent = phone || 'N/A';
      userAvatarInitial.textContent = username.charAt(0).toUpperCase();

      landingView.classList.add('hidden');
      appView.classList.remove('hidden');
      hideAuthModal();
    });
  }

  // --- LOGOUT ---
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      currentUser = null;
      loginForm.reset();
      appView.classList.add('hidden');
      landingView.classList.remove('hidden');
    });
  }

  // --- STATUS UPDATE ---
  if (editStatusBtn && statusModal) {
    editStatusBtn.addEventListener('click', () => {
      if (statusInput && displayStatus) {
        statusInput.value = displayStatus.textContent;
      }
      statusModal.classList.remove('hidden');
    });
  }

  if (closeStatusModal && statusModal) {
    closeStatusModal.addEventListener('click', () => statusModal.classList.add('hidden'));
  }

  if (statusForm && statusModal) {
    statusForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const newStatus = statusInput.value.trim();
      if (newStatus && displayStatus) {
        displayStatus.textContent = newStatus;
        if (currentUser) currentUser.status = newStatus;
      }
      statusModal.classList.add('hidden');
    });
  }

  // --- CONTACTS MODAL ---
  if (contactsBtn && contactsModal) {
    contactsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      contactsModal.classList.remove('hidden');
    });
  }

  if (closeContactsModal && contactsModal) {
    closeContactsModal.addEventListener('click', () => contactsModal.classList.add('hidden'));
  }

  // --- NOTIFICATIONS SYSTEM ---
  function renderNotifications() {
    if (!notifContainer) return;
    notifContainer.innerHTML = '';

    if (notifications.length === 0) {
      notifContainer.innerHTML = `
        <div class="empty-state">
          <i class="fa-regular fa-bell-slash"></i>
          <p>No new notifications right now!</p>
          <small style="color: var(--text-muted);">You're all caught up. Check back later!</small>
        </div>
      `;
      if (notifBadge) notifBadge.classList.add('hidden');
    } else {
      notifications.forEach((item) => {
        const div = document.createElement('div');
        div.className = 'notif-item';
        div.textContent = item.text;
        notifContainer.appendChild(div);
      });
      if (notifBadge) {
        notifBadge.textContent = notifications.length;
        notifBadge.classList.remove('hidden');
      }
    }
  }

  if (notificationsBtn && notifModal) {
    notificationsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      renderNotifications();
      notifModal.classList.remove('hidden');
    });
  }

  if (closeNotifModal && notifModal) {
    closeNotifModal.addEventListener('click', () => notifModal.classList.add('hidden'));
  }

  // --- LIVE CHAT FUNCTIONALITY ---
  if (chatForm && messageInput && messagesList) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const text = messageInput.value.trim();
      if (!text) return;

      const messageCard = document.createElement('div');
      messageCard.classList.add('chat-bubble', 'own');

      const senderDiv = document.createElement('div');
      senderDiv.classList.add('sender-name');
      senderDiv.textContent = currentUser ? `@${currentUser.username}` : '@you';

      const textDiv = document.createElement('div');
      textDiv.textContent = text;

      messageCard.appendChild(senderDiv);
      messageCard.appendChild(textDiv);
      messagesList.appendChild(messageCard);

      messageInput.value = '';
      messagesList.scrollTop = messagesList.scrollHeight;
    });
  }
});